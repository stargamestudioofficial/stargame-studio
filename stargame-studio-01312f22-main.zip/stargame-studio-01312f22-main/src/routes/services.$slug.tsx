import { createFileRoute, notFound } from "@tanstack/react-router";
import { Shell, PageBody } from "@/components/sg/Shell";
import { SERVICES, pageHead } from "@/content/site";

export const Route = createFileRoute("/services/$slug")({
  loader: ({ params }) => {
    const page = SERVICES.find((s) => s.slug === params.slug);
    if (!page) throw notFound();
    return page;
  },
  head: ({ loaderData, params }) =>
    loaderData
      ? pageHead({
          metaTitle: loaderData.metaTitle, description: loaderData.description, path: `/services/${params.slug}`,
          jsonLd: [{ "@context": "https://schema.org", "@type": "Service", name: loaderData.title, serviceType: loaderData.serviceType, description: loaderData.description, areaServed: "Worldwide", provider: { "@type": "Organization", name: "Stargame Studio", address: { "@type": "PostalAddress", addressCountry: "TT" } } }],
        })
      : { meta: [{ title: "Unavailable — Stargame Studio" }, { name: "robots", content: "noindex" }] },
  component: () => <Shell><PageBody page={Route.useLoaderData()} /></Shell>,
});
