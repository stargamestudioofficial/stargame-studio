import { createFileRoute } from "@tanstack/react-router";
import { Shell, PageBody } from "@/components/sg/Shell";
import { PAGES, ORG_LD, pageHead } from "@/content/site";

const page = PAGES["why-human-art"];

export const Route = createFileRoute("/why-human-art")({
  head: () => pageHead({ metaTitle: page.metaTitle, description: page.description, path: "/why-human-art", jsonLd: [ORG_LD] }),
  component: () => <Shell><PageBody page={page} /></Shell>,
});
