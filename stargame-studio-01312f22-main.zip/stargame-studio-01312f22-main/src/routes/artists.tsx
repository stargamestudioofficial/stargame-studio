import { createFileRoute } from "@tanstack/react-router";
import { Shell, PageBody } from "@/components/sg/Shell";
import { PAGES, ORG_LD, pageHead } from "@/content/site";

const page = PAGES["artists"];

export const Route = createFileRoute("/artists")({
  head: () => pageHead({ metaTitle: page.metaTitle, description: page.description, path: "/artists", jsonLd: [ORG_LD] }),
  component: () => <Shell><PageBody page={page} /></Shell>,
});
