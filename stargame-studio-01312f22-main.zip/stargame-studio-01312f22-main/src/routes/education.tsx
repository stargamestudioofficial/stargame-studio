import { createFileRoute } from "@tanstack/react-router";
import { Shell, PageBody } from "@/components/sg/Shell";
import { PAGES, ORG_LD, pageHead } from "@/content/site";

const page = PAGES["education"];

export const Route = createFileRoute("/education")({
  head: () => pageHead({ metaTitle: page.metaTitle, description: page.description, path: "/education", jsonLd: [ORG_LD] }),
  component: () => <Shell><PageBody page={page} /></Shell>,
});
