import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Shell } from "@/components/sg/Shell";
import { pageHead, SERVICES, STUDIO } from "@/content/site";
import { submitCommission } from "@/lib/commissions.functions";

export const Route = createFileRoute("/commission")({
  head: () => pageHead({
    metaTitle: "Request a Commission | Stargame Studio — Human-Made Art",
    description: "Commission Stargame Studio for Roblox, UGC, 2D clothing, game art, flyers and event medals. Hand-made by real artists in Trinidad and Tobago.",
    path: "/commission",
  }),
  component: CommissionPage,
});

const field = "mt-1 w-full rounded-md border border-border bg-card px-3 py-2 text-foreground";

function CommissionPage() {
  const send = useServerFn(submitCommission);
  const [state, setState] = useState<"idle" | "sending" | "done" | string>("idle");
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>;
    setState("sending");
    try {
      const r = await send({ data: f });
      setState(r.ok ? "done" : r.error);
    } catch {
      setState("Please check the form: name, a valid email and a few words of detail are needed.");
    }
  }
  if (state === "done") return <Shell><h1 className="sg-display text-4xl text-primary">Request received ⭐</h1><p className="mt-4 text-muted-foreground">Thank you! We'll reach out by email or Discord to agree the details and price.</p></Shell>;
  return (
    <Shell>
      <h1 className="sg-display text-4xl text-primary">Request a commission</h1>
      <p className="mt-3 text-muted-foreground">Tell us what you'd like made. Prefer chatting? Email <a className="text-primary underline" href={`mailto:${STUDIO.email}`}>{STUDIO.email}</a> or join our <a className="text-primary underline" href={STUDIO.discordInvite} target="_blank" rel="noopener">Discord</a>.</p>
      <form onSubmit={onSubmit} className="mt-8 grid gap-4">
        <label>Name<input name="name" required maxLength={100} className={field} /></label>
        <label>Email<input name="email" type="email" required maxLength={255} className={field} /></label>
        <label>Discord username (optional)<input name="discord" maxLength={100} className={field} /></label>
        <label>Service<select name="service" className={field}>{SERVICES.map((s) => <option key={s.slug}>{s.title}</option>)}<option>Other</option></select></label>
        <label>Number of designs<input name="designs" type="number" min={1} max={500} defaultValue={1} className={field} /></label>
        <label>Budget (optional)<input name="budget" maxLength={100} placeholder="e.g. US$30" className={field} /></label>
        <label>Details<textarea name="details" required minLength={5} maxLength={3000} rows={6} className={field} /></label>
        {state !== "idle" && state !== "sending" && <p className="text-destructive">{state}</p>}
        <button disabled={state === "sending"} className="rounded-md bg-primary px-5 py-3 font-bold text-primary-foreground disabled:opacity-60">{state === "sending" ? "Sending…" : "Send request"}</button>
      </form>
    </Shell>
  );
}
