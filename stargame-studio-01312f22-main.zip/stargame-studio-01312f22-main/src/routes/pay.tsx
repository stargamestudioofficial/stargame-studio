import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell } from "@/components/sg/Shell";
import { pageHead } from "@/content/site";
import { BASE_PRICE_USD, BULK_PRICE_USD, BULK_MIN, RATES, convert, promoDiscount, totalUSD, unitPrice, type Currency } from "@/lib/pricing";

const SYMBOL: Record<Currency, string> = { USD: "US$", TTD: "TT$", EUR: "€", PHP: "₱" };
const fmt = (usd: number, c: Currency) => `${SYMBOL[c]}${convert(usd, c).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export const Route = createFileRoute("/pay")({
  head: () => pageHead({ metaTitle: "Pay for Your Art or Design Commission | Stargame Studio", description: "Designs from US$10 each, US$5 each for more than 5. Prices shown in USD, TTD, EUR and PHP — Stargame Studio accepts clients from every country.", path: "/pay" }),
  component: PayPage,
});

function PayPage() {
  const [mode, setMode] = useState<"designs" | "custom">("designs");
  const [qty, setQty] = useState(1);
  const [custom, setCustom] = useState("");
  const [code, setCode] = useState("");
  const discount = promoDiscount(code);
  const total = mode === "designs" ? totalUSD(qty, code) : Math.round((Number(custom) || 0) * (1 - discount) * 100) / 100;

  return (
    <Shell>
      <h1 className="sg-display text-4xl text-primary md:text-5xl">Make a payment</h1>
      <p className="mt-5 text-muted-foreground">
        Any design (flyer, logo, medal, Roblox clothing, thumbnail and more): <b className="text-foreground">US${BASE_PRICE_USD} each</b>, or <b className="text-foreground">US${BULK_PRICE_USD} each</b> when you order more than {BULK_MIN}. We accept clients from every country.
      </p>

      <div className="mt-8 grid gap-3 sm:grid-cols-2">
        <button onClick={() => setMode("designs")} className={`rounded-lg border px-4 py-3 text-left ${mode === "designs" ? "border-primary" : "border-border"} bg-card`}>Pay per design</button>
        <button onClick={() => setMode("custom")} className={`rounded-lg border px-4 py-3 text-left ${mode === "custom" ? "border-primary" : "border-border"} bg-card`}>Custom / quoted amount</button>
      </div>

      <div className="mt-6 grid gap-4 rounded-xl border border-border bg-card p-6">
        {mode === "designs" ? (
          <label className="flex items-center justify-between gap-4">
            <span>Number of designs</span>
            <input type="number" min={1} value={qty} onChange={(e) => setQty(Math.max(1, Number(e.target.value) || 1))} className="w-24 rounded-md border border-input bg-background px-3 py-1" />
          </label>
        ) : (
          <label className="flex items-center justify-between gap-4">
            <span>Quoted amount (USD)</span>
            <input type="number" min={1} value={custom} onChange={(e) => setCustom(e.target.value)} placeholder="e.g. 75" className="w-28 rounded-md border border-input bg-background px-3 py-1" />
          </label>
        )}
        <label className="flex items-center justify-between gap-4">
          <span>Discount code</span>
          <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="SG2026" className="w-32 rounded-md border border-input bg-background px-3 py-1 uppercase" />
        </label>
        {code && <p className="text-sm text-muted-foreground">{discount ? `Code applied: ${discount * 100}% off` : "That code isn't valid."}</p>}
        {mode === "designs" && <p className="text-sm text-muted-foreground">{qty} × US${unitPrice(qty)} per design</p>}
        <div className="grid grid-cols-2 gap-2 border-t border-border pt-4 sm:grid-cols-4">
          {(Object.keys(RATES) as Currency[]).map((c) => (
            <div key={c} className="rounded-md bg-muted px-3 py-2">
              <p className="text-xs text-muted-foreground">{c}</p>
              <p className="font-bold">{fmt(total, c)}</p>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground">TTD, EUR and PHP amounts are approximate; you're charged the US dollar amount.</p>
      </div>

      <button disabled className="mt-8 w-full rounded-md bg-primary px-5 py-3 font-bold text-primary-foreground opacity-60">
        Pay {fmt(total, "USD")} — card payments coming soon
      </button>
      <p className="mt-3 text-sm text-muted-foreground">We may ask for a 50% upfront deposit on larger commissions.</p>
    </Shell>
  );
}
