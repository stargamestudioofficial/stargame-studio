import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/sg/Shell";
import { FAQ, pageHead } from "@/content/site";

export const Route = createFileRoute("/faq")({
  head: () => pageHead({ metaTitle: "FAQ — Stargame Studio (SG), Trinidad and Tobago", description: "Answers about Stargame Studio: who we are, where we're based, medal and Roblox commissions, human-made art and how to pay.", path: "/faq", jsonLd: [{ "@context": "https://schema.org", "@type": "FAQPage", mainEntity: FAQ.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })) }] }),
  component: () => (
    <Shell>
      <h1 className="sg-display text-4xl text-primary md:text-5xl">Questions & answers</h1>
      <dl className="mt-10 space-y-6">
        {FAQ.map((f) => (
          <div key={f.q} className="rounded-xl border border-border bg-card p-5">
            <dt className="font-bold">{f.q}</dt>
            <dd className="mt-2 text-muted-foreground">{f.a}</dd>
          </div>
        ))}
      </dl>
    </Shell>
  ),
});
