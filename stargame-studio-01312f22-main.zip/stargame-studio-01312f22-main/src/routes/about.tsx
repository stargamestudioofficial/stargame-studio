import { createFileRoute } from "@tanstack/react-router";
import { Shell, PageBody } from "@/components/sg/Shell";
import { PAGES, ORG_LD, pageHead } from "@/content/site";

const page = PAGES["about"];

export const Route = createFileRoute("/about")({
  head: () => pageHead({ metaTitle: page.metaTitle, description: page.description, path: "/about", jsonLd: [ORG_LD] }),
  component: () => <Shell><PageBody page={page} /></Shell>,
});
