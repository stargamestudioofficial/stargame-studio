import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/sg/Shell";
import { SERVICES, ORG_LD, pageHead } from "@/content/site";

export const Route = createFileRoute("/services/")({
  head: () => pageHead({ metaTitle: "Services: Graphic Design, Medals, Roblox & Game Development | Stargame Studio", description: "Hire Stargame Studio for graphic design, 5K medal designs, flyers, Roblox games, UGC, 2D Roblox clothing and PC games. Human-made, from Trinidad and Tobago.", path: "/services", jsonLd: [ORG_LD] }),
  component: ServicesPage,
});

function ServicesPage() {
  return (
    <Shell>
      <h1 className="sg-display text-4xl text-primary md:text-5xl">Our services</h1>
      <p className="mt-5 text-lg text-muted-foreground">Everything Stargame Studio makes — all by human artists and developers.</p>
      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        {SERVICES.map((s) => (
          <Link key={s.slug} to="/services/$slug" params={{ slug: s.slug }} className="rounded-xl border border-border bg-card p-6 hover:border-primary">
            <h2 className="text-xl font-bold">{s.title}</h2>
            <p className="mt-2 text-sm text-muted-foreground">{s.description}</p>
          </Link>
        ))}
      </div>
    </Shell>
  );
}
