import { describe, it, expect } from "vitest";
import { totalUSD, unitPrice, promoDiscount } from "@/lib/pricing";

describe("commission pricing", () => {
  it("charges $10 per design up to 5 designs", () => {
    expect(unitPrice(5)).toBe(10);
    expect(totalUSD(5)).toBe(50);
  });
  it("charges $5 per design when ordering more than 5", () => {
    expect(unitPrice(6)).toBe(5);
    expect(totalUSD(6)).toBe(30);
  });
  it("SG2026 gives 20% off", () => {
    expect(promoDiscount("sg2026")).toBe(0.2);
    expect(totalUSD(1, "SG2026")).toBe(8);
  });
  it("unknown codes give no discount", () => {
    expect(totalUSD(1, "FAKE")).toBe(10);
  });
});
