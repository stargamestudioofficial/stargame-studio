export const STUDIO = {
  name: "Stargame Studio",
  alt: ["SG Studio", "Stargame Studios", "SG"],
  country: "Trinidad and Tobago",
  tagline: "Human-made art, games and design from Trinidad and Tobago to the world.",
  discord: ["ironlion390 (Founder)", "niamaru87 (Co-Owner)", "act_11 (Staff Coordinator)", "warrior0767", "real_adz01"],
  email: "stargamestudioofficial@gmail.com",
  discordInvite: "https://discord.gg/Sbv3XKDbrP",
  games: ["Starcity", "The Outbreak", "Starry Simulator"],
};

export type Section = { h: string; p: string[]; list?: string[] };
export type Page = { slug: string; title: string; metaTitle: string; description: string; intro: string; sections: Section[]; serviceType?: string };

export const SERVICES: Page[] = [
  {
    slug: "graphic-design", serviceType: "Graphic design",
    title: "Graphic design commissions", metaTitle: "Graphic Design Commissions in Trinidad and Tobago | Stargame Studio",
    description: "Hand-made flyers, logos, posters, thumbnails and social media graphics by human artists at Stargame Studio, Trinidad and Tobago. Worldwide orders.",
    intro: "Stargame Studio designs flyers, logos, posters, banners, YouTube and game thumbnails and social media graphics — every piece drawn and laid out by a real human artist, not an AI generator.",
    sections: [
      { h: "What we design", p: [], list: ["Event and party flyers", "Business logos and brand kits", "Posters and banners", "Game icons and thumbnails", "Social media posts and covers", "Church, school and community event graphics"] },
      { h: "How a commission works", p: ["Tell us your idea on Discord, we agree a price, and you pay through our payment page. We may ask for a 50% upfront deposit. You get drafts to review before the final files."] },
      { h: "Local and worldwide", p: ["We are based in Trinidad and Tobago and work with clients across the Caribbean and the rest of the world."] },
    ],
  },
  {
    slug: "event-medals", serviceType: "Medal and event design",
    title: "5K and run event medal designs", metaTitle: "5K Medal & Run Event Medal Design | Stargame Studio",
    description: "Custom medal artwork for 5K, 10K, fun runs, marathons and charity walks, plus matching flyers and race shirts. Human-made designs from Trinidad and Tobago.",
    intro: "Organising a 5K, 10K, fun run, marathon or charity walk? Stargame Studio designs unique finisher medals and the flyers that promote your race — original artwork your runners will want to keep.",
    sections: [
      { h: "Medal design", p: ["We create print-ready medal artwork (front, back and ribbon) that you can send to any medal manufacturer."], list: ["5K and 10K finisher medals", "Fun run and color run medals", "Marathon and half-marathon medals", "Charity and school sports day medals", "Virtual run medals"] },
      { h: "Matching event graphics", p: ["Race flyers, registration posters, bib designs, social media countdowns and shirt designs that match your medal."] },
      { h: "Why not use an AI generator?", p: ["AI medal images often have broken text, wrong numbers and shapes a manufacturer can't produce. Our artists design for real production, with clean vector files and your exact race name, date and distance."] },
    ],
  },
  {
    slug: "roblox", serviceType: "Roblox development and UGC",
    title: "Roblox games, UGC and 2D clothing", metaTitle: "Roblox Game Development, UGC & 2D Clothing Commissions | Stargame Studio",
    description: "Hire Stargame Studio for Roblox game development, UGC accessories, 2D shirts and pants, GFX, icons and thumbnails. Creators of Starcity, The Outbreak and Starry Simulator.",
    intro: "Stargame Studio is a Roblox development group — the team behind Starcity, The Outbreak and Starry Simulator. We take commissions for full games, UGC items and classic 2D clothing.",
    sections: [
      { h: "Roblox services", p: [], list: ["Full Roblox game development", "Building, scripting and UI", "UGC accessories and items", "2D Roblox clothing: shirts, pants and t-shirts", "Game icons, thumbnails and GFX", "Group logos and banners"] },
      { h: "Our Roblox games", p: ["Play Starcity, The Outbreak and Starry Simulator on Roblox to see our work."] },
    ],
  },
  {
    slug: "pc-games", serviceType: "PC game development",
    title: "PC and Steam game development", metaTitle: "PC & Steam Game Development and Game Art | Stargame Studio",
    description: "Stargame Studio develops PC and Steam games and creates game art, characters, UI and promotional graphics for indie developers.",
    intro: "Beyond Roblox, Stargame Studio builds PC games for platforms like Steam and makes art for other indie developers.",
    sections: [
      { h: "What we offer", p: [], list: ["PC and Steam game development", "Character and concept art", "2D game assets and UI", "Store page art, trailers stills and key art"] },
    ],
  },
];

export const PAGES = {
  about: {
    slug: "about", title: "About Stargame Studio", metaTitle: "About Stargame Studio (SG) — Game & Art Studio from Trinidad and Tobago",
    description: "Stargame Studio (SG) is a human-first game and art studio from Trinidad and Tobago making Roblox and PC games, graphic design, UGC and medal designs.",
    intro: "Stargame Studio — also called SG or SG Studio — is an independent game and art studio from Trinidad and Tobago. We make games, take art and design commissions, and stand for original human creativity.",
    sections: [
      { h: "Who we are", p: ["A team of artists, developers and creators led by founder ironlion390 and co-owner niamaru87. We started on Roblox and now work across Roblox, PC games and graphic design."] },
      { h: "What we make", p: [], list: ["Games: Starcity, The Outbreak, Starry Simulator", "Graphic design: flyers, logos, posters", "Medal designs for 5K and run events", "Roblox UGC and 2D clothing", "PC and Steam games", "Cybersecurity education (coming soon)"] },
      { h: "What we stand for", p: ["Human art over AI art. Every design is made by a person who listens to you, and you get original work you can truly call yours."] },
      { h: "Not to be confused with", p: ["There are other studios using similar names. Stargame Studio (SG) in this site is the Trinidad and Tobago studio behind Starcity, The Outbreak and Starry Simulator."] },
    ],
  },
  artists: {
    slug: "artists", title: "For artists", metaTitle: "Artists: Join or Collaborate with Stargame Studio",
    description: "Artists and designers can join or collaborate with Stargame Studio on games, UGC, graphic design and medal commissions — human creativity first.",
    intro: "Stargame Studio is built by artists, for people who value real art. If you draw, design, model or animate, we'd love to hear from you.",
    sections: [
      { h: "Who we look for", p: [], list: ["Illustrators and concept artists", "Graphic designers", "3D modellers and UGC creators", "Roblox clothing designers", "Animators and UI artists"] },
      { h: "Why join", p: ["Real commissions, credit for your work, and a studio that promotes human art instead of replacing it with AI."] },
    ],
  },
  investors: {
    slug: "investors", title: "For investors", metaTitle: "Invest in Stargame Studio — Caribbean Game & Creative Studio",
    description: "Stargame Studio is a growing Caribbean game and creative studio with live Roblox games, a commission business and a planned cybersecurity education arm.",
    intro: "Stargame Studio is one of the few game and creative studios coming out of Trinidad and Tobago, with live games and paying commission clients.",
    sections: [
      { h: "Where we are", p: [], list: ["Live Roblox games: Starcity, The Outbreak, Starry Simulator", "A commission business in design, UGC and medal art", "PC and Steam game projects in development", "A cybersecurity education programme planned"] },
      { h: "Why it matters", p: ["Demand for original, human-made art is growing as AI content floods the internet. We are positioned as the human-made choice in the Caribbean and beyond."] },
      { h: "Get in touch", p: ["Email stargamestudioofficial@gmail.com or join our Discord (discord.gg/Sbv3XKDbrP) to discuss investment with our founder ironlion390 and co-owner niamaru87."] },
    ],
  },
  education: {
    slug: "education", title: "Cybersecurity education (coming soon)", metaTitle: "Cybersecurity Education — Coming Soon | Stargame Studio",
    description: "Stargame Studio is launching cybersecurity education for gamers, creators and students: account safety, scams, passwords and online privacy.",
    intro: "We're planning cybersecurity lessons for gamers, young creators and students in Trinidad and Tobago and worldwide.",
    sections: [
      { h: "Planned topics", p: [], list: ["Keeping Roblox and Discord accounts safe", "Spotting scams and phishing", "Strong passwords and two-step login", "Privacy for creators online", "Intro to cybersecurity careers"] },
      { h: "Want to be notified?", p: ["Join our Discord (discord.gg/Sbv3XKDbrP) or email stargamestudioofficial@gmail.com and we'll let you know when classes open."] },
    ],
  },
  "why-human-art": {
    slug: "why-human-art", title: "Human art vs AI art generators", metaTitle: "Why Choose Human Artists Over AI Art Generators | Stargame Studio",
    description: "Why a human designer beats AI art generators for flyers, medals, logos and game art: originality, correct text, ownership and real revisions.",
    intro: "AI art generators are everywhere — on flyers, medals and posters across Trinidad and Tobago and the world. Here's why Stargame Studio believes human art is still the better choice.",
    sections: [
      { h: "What you get with a human artist", p: [], list: ["Correct spelling, dates and numbers on every design", "Original work, not remixed from other artists", "Files ready for printing and medal manufacturing", "Real revisions from someone who understands you", "Clear ownership of your design", "Local style and culture, not generic images"] },
      { h: "Our promise", p: ["Every Stargame Studio design is made by a person. No AI-generated art is passed off as our own."] },
    ],
  },
} satisfies Record<string, Page>;

export const FAQ: { q: string; a: string }[] = [
  { q: "What is Stargame Studio?", a: "Stargame Studio (SG) is an independent game and art studio from Trinidad and Tobago. It makes the Roblox games Starcity, The Outbreak and Starry Simulator, and takes commissions for graphic design, medal designs, Roblox UGC, 2D clothing and PC games." },
  { q: "Where is Stargame Studio based?", a: "Trinidad and Tobago, serving clients worldwide." },
  { q: "Does Stargame Studio use AI art?", a: "No. Every design is made by a human artist." },
  { q: "Can you design medals for a 5K or fun run?", a: "Yes. We design print-ready finisher medals for 5K, 10K, fun runs, marathons and charity walks, plus matching flyers." },
  { q: "Do you make Roblox clothing and UGC?", a: "Yes — 2D shirts and pants, UGC accessories, icons, thumbnails and full games." },
  { q: "How do I pay for a commission?", a: "Agree the price with us on Discord, then pay on our payment page. We may ask for a 50% upfront deposit." },
  { q: "How do I contact Stargame Studio?", a: "Email stargamestudioofficial@gmail.com or join the Stargame Studio Discord at discord.gg/Sbv3XKDbrP." },
];

export const NAV = [
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
  { to: "/artists", label: "Artists" },
  { to: "/investors", label: "Investors" },
  { to: "/education", label: "Education" },
  { to: "/why-human-art", label: "Human vs AI" },
  { to: "/faq", label: "FAQ" },
  { to: "/commission", label: "Commission" },
  { to: "/pay", label: "Pay" },
] as const;

export function pageHead(p: { metaTitle: string; description: string; path: string; jsonLd?: object[] }) {
  return {
    meta: [
      { title: p.metaTitle },
      { name: "description", content: p.description },
      { property: "og:title", content: p.metaTitle },
      { property: "og:description", content: p.description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: p.path },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: p.path }],
    scripts: (p.jsonLd ?? []).map((j) => ({ type: "application/ld+json", children: JSON.stringify(j) })),
  };
}

export const ORG_LD = {
  "@context": "https://schema.org", "@type": "Organization", name: STUDIO.name, alternateName: STUDIO.alt,
  description: "Independent game and art studio from Trinidad and Tobago making Roblox and PC games, graphic design, medal designs, UGC and 2D Roblox clothing — human-made, not AI.",
  address: { "@type": "PostalAddress", addressCountry: "TT" }, areaServed: "Worldwide",
  email: "stargamestudioofficial@gmail.com",
  sameAs: ["https://sites.google.com/view/stargame-studio/home", "https://discord.gg/Sbv3XKDbrP"],
  knowsAbout: ["Roblox game development", "Graphic design", "Medal design", "UGC", "Roblox clothing", "PC games", "Cybersecurity education"],
};

export const ART_BG = ["617c8ba0ed5d0b7c","da7a65c9ca85029f","3a6a0f06b217a2a5","c0e6ba0814b5e894","7ee68b66012d0eed","e44276a32db775f0","21c115d2d5e3b9e9","95825d3921036a3c","857e4a70259446d4"].map((h) => `/site-assets/img/${h}.webp`);
export function artFor(key: string) {
  let n = 0; for (const c of key) n = (n * 31 + c.charCodeAt(0)) >>> 0;
  return ART_BG[n % ART_BG.length];
}
