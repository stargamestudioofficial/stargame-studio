import { useEffect, useState } from "react";

export const LANGS = [
  ["en", "English"], ["es", "Español"], ["ru", "Русский"], ["fr", "Français"], ["pt", "Português"],
  ["de", "Deutsch"], ["it", "Italiano"], ["nl", "Nederlands"], ["tl", "Filipino"], ["hi", "हिन्दी"],
  ["zh-CN", "中文"], ["ja", "日本語"], ["ko", "한국어"], ["ar", "العربية"], ["tr", "Türkçe"], ["pl", "Polski"],
] as const;

declare global { interface Window { googleTranslateElementInit?: () => void; google?: any } }

function setCookie(lang: string) {
  const v = lang === "en" ? "" : `/en/${lang}`;
  const exp = lang === "en" ? "; expires=Thu, 01 Jan 1970 00:00:00 GMT" : "";
  document.cookie = `googtrans=${v}; path=/${exp}`;
  document.cookie = `googtrans=${v}; path=/; domain=${location.hostname}${exp}`;
}

export function LanguagePicker({ className = "" }: { className?: string }) {
  const [lang, setLang] = useState("en");
  useEffect(() => {
    const m = document.cookie.match(/googtrans=\/en\/([^;]+)/);
    if (m?.[1]) setLang(m[1]);
    if (document.getElementById("gt-script")) return;
    window.googleTranslateElementInit = () => {
      new window.google.translate.TranslateElement({ pageLanguage: "en", autoDisplay: false }, "google_translate_element");
    };
    const s = document.createElement("script");
    s.id = "gt-script";
    s.src = "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
    document.body.appendChild(s);
  }, []);
  return (
    <>
      <div id="google_translate_element" style={{ display: "none" }} />
      <label className={className}>
        <span className="sr-only">Language</span>
        <select
          className="notranslate rounded-md border border-border bg-card px-2 py-1 text-sm text-foreground"
          value={lang}
          onChange={(e) => { setCookie(e.target.value); location.reload(); }}
          aria-label="Language"
        >
          {LANGS.map(([c, n]) => <option key={c} value={c}>{n}</option>)}
        </select>
      </label>
    </>
  );
}
