import { Link, useRouterState } from "@tanstack/react-router";
import { LanguagePicker } from "./LanguagePicker";
import type { ReactNode } from "react";
import { NAV, STUDIO, artFor, type Page } from "@/content/site";

export function SiteFooterNav() {
  return (
    <footer className="sg-theme border-t border-border bg-background px-6 py-10 text-foreground">
      <div className="mx-auto max-w-5xl">
        <p className="sg-display text-xl text-primary">{STUDIO.name}</p>
        <p className="mt-1 text-sm text-muted-foreground">{STUDIO.tagline}</p>
        <nav className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-sm" aria-label="Footer">
          <Link to="/" className="hover:text-primary">Home</Link>
          {NAV.map((n) => <Link key={n.to} to={n.to} className="hover:text-primary">{n.label}</Link>)}
          <Link to="/services/$slug" params={{ slug: "event-medals" }} className="hover:text-primary">Medal design</Link>
          <Link to="/services/$slug" params={{ slug: "roblox" }} className="hover:text-primary">Roblox & UGC</Link>
        </nav>
        <p className="mt-4 text-sm text-muted-foreground">
          <a href={`mailto:${STUDIO.email}`} className="hover:text-primary">{STUDIO.email}</a> · <a href={STUDIO.discordInvite} target="_blank" rel="noopener" className="hover:text-primary">Discord</a>
        </p>
      </div>
    </footer>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="sg-theme sg-art min-h-screen bg-background text-foreground" style={{ backgroundImage: `linear-gradient(color-mix(in oklab, var(--background) 82%, transparent), color-mix(in oklab, var(--background) 92%, transparent)), url(${artFor(useRouterState({ select: (r) => r.location.pathname }) + "bg")})` }}>
      <header className="sticky top-0 z-50 border-b border-border bg-background/90 backdrop-blur">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-x-5 gap-y-2 px-6 py-3">
          <Link to="/" className="sg-display mr-auto text-lg text-primary">⭐ Stargame Studio</Link>
          <nav className="flex flex-wrap gap-x-4 gap-y-1 text-sm" aria-label="Main">
            {NAV.map((n) => (
              <Link key={n.to} to={n.to} className="hover:text-primary" activeProps={{ className: "text-primary" }}>{n.label}</Link>
            ))}
          </nav>
          <LanguagePicker />
        </div>
      </header>
      <main className="mx-auto max-w-3xl px-6 py-14"><div className="rounded-2xl border border-border bg-background/75 p-6 shadow-2xl backdrop-blur md:p-10">{children}</div></main>
      <SiteFooterNav />
    </div>
  );
}

export function PageBody({ page }: { page: Page }) {
  return (
    <article>
      <div className="sg-art -mx-6 -mt-6 mb-6 overflow-hidden rounded-t-2xl px-6 py-14 md:-mx-10 md:-mt-10 md:px-10" style={{ backgroundImage: `linear-gradient(to top, var(--background), transparent 70%), url(${artFor(page.slug)})`, backgroundAttachment: "scroll" }}>
        <h1 className="sg-display text-4xl leading-tight text-primary drop-shadow-lg md:text-5xl">{page.title}</h1>
      </div>
      <p className="mt-5 text-lg text-muted-foreground">{page.intro}</p>
      {page.sections.map((s) => (
        <section key={s.h} className="mt-10">
          <h2 className="text-2xl font-bold">{s.h}</h2>
          {s.p.map((t) => <p key={t} className="mt-3 text-muted-foreground">{t}</p>)}
          {s.list && (
            <ul className="mt-4 grid gap-2 sm:grid-cols-2">
              {s.list.map((li) => <li key={li} className="rounded-lg border border-primary/30 bg-card/80 px-4 py-3">✦ {li}</li>)}
            </ul>
          )}
        </section>
      ))}
      <div className="mt-12 rounded-xl border border-border bg-card p-6">
        <p className="font-bold">Ready to commission Stargame Studio?</p>
        <p className="mt-1 text-sm text-muted-foreground">Email <a className="text-primary underline" href={`mailto:${STUDIO.email}`}>{STUDIO.email}</a> or join our Discord to agree a price, then pay on our payment page.</p>
        <div className="mt-4 flex flex-wrap gap-3">
          <a href={STUDIO.discordInvite} target="_blank" rel="noopener" className="rounded-md border border-primary px-5 py-2 font-bold text-primary">Join our Discord</a>
          <Link to="/commission" className="rounded-md border border-primary px-5 py-2 font-bold text-primary">Request a commission</Link>
          <Link to="/pay" className="rounded-md bg-primary px-5 py-2 font-bold text-primary-foreground">Make a payment</Link>
        </div>
      </div>
    </article>
  );
}
